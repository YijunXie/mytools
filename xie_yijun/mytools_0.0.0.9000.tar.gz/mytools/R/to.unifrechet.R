# Require package "Hsmic".
# This function transform the data to a unit Frechet distribution.
# Input: vector of data = dat
# Output: transformed data = res
to.unitfrechet = function(dat){
	# create an empty vector to store transferred data
	ind = rep(0,length(dat))
	# find empirical cdf of the original data
	cdfs = Ecdf(dat,pl = F)
	# remove the first one (F(`) = 0)
	tempx = cdfs$x[-1]
	# match the quantile of old data to the quantile of unit Frechet
	for(i in 1:length(dat)){
		ind[i] = which(dat == tempx[i])
	}
	fx = cdfs$y[ind]
	# find the corresponding value in unit Frechet
	res = -1 / log(fx)
	return(res)
}
