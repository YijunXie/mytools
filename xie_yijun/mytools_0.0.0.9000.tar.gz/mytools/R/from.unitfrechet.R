# transfer the processed unit Frechet data back to the original data
# Input: vector of unit Frechet data = ufdat; old data = odat
# Output: new data = x
from.unitfrechet = function(ufdat,odat){
	# find the quantile of each unit Frechet data
	cd = exp(-1 / ufdat)
	# match quantile
	x = quantile(odat,cd)
	return(x)
}
