# functional for expection
fn = function(l1,l2,kappa,inov = "norm",df=1){
	# normal distribution
	if(inov == "norm"){
		intf = function(x){
			2*((l1*x^2+l2)^kappa)*dnorm(x)
		}
	}

	# t distribution
	if(inov == "std"){
		intf = function(x){
			2*((l1*x^2+l2)^kappa)*dt(x,df = df)
		}
	}
	return(intf)
}
