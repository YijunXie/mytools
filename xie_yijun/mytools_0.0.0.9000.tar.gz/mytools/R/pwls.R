# Piecewise linear scroing function
# Input: predicted value = x; true value = t; quantile = q;
pwls = function(x,t,q){
	if(x <= t){
		# I(x<t)(\alpha|x-t|)
		s = q*abs(x-t)
	} else {
		# I(x>t)((1-\alpha)|x-t|)
		s = (1-q)*abs(x-t)
	}
	return(s)
}
